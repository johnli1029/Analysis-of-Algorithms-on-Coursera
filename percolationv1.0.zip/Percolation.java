
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation 
{
	private int N;
	private int count;
	private boolean[][] a;
	private WeightedQuickUnionUF uf;
	
	public Percolation(int n)				 // create n-by-n grid, with all sites blocked
	{
		if (n <= 0) 
		{
            throw new IllegalArgumentException("index n should be larger than 1.");  
        }
		N = n;
		count = 0;
		uf = new WeightedQuickUnionUF(N*N+2);	// The first (N*N) sites are grid sites. (N*N + 1) is the top site and (N*N + 2) is the bottom site
		a = new boolean[N][N];
		for(int i = 0; i < N; ++i)
		{
			for(int j = 0; j < N; ++j)
			{
				a[i][j] = false;
			}		
		}
	}
	
	public void open(int row, int col)    	 // open site (row, col) if it is not open already
	{
		if (row <= 0 || row > N) 
		{
            throw new IllegalArgumentException("index " + row + " is not between 1 and " + N);  
        }
		if (col <= 0 || col > N) 
		{
            throw new IllegalArgumentException("index " + col + " is not between 1 and " + N);  
        }
		
		row = row-1;
		col = col-1;
		if(!a[row][col])
		{
			a[row][col] = true;
			count++;
			if(row-1 >= 0 && a[row-1][col])
				uf.union(row*N+col, (row-1)*N+col);
			if(row+1 <= N-1 && a[row+1][col])
				uf.union(row*N+col, (row+1)*N+col);
			if(col+1 <= N-1 && a[row][col+1])
				uf.union(row*N+col, row*N+col+1);
			if(col-1 >= 0 && a[row][col-1])
				uf.union(row*N+col, row*N+col-1);
			if(row == 0)
				uf.union(col, N*N);
			if(row == N-1)
				uf.union(N*(N-1)+col, N*N+1);
		}
	}
	
	public boolean isOpen(int row, int col)  // is site (row, col) open?
	{
		if (row <= 0 || row > N) 
		{
            throw new IllegalArgumentException("index " + row + " is not between 1 and " + N);  
        }
		if (col <= 0 || col > N) 
		{
            throw new IllegalArgumentException("index " + col + " is not between 1 and " + N);  
        }
		
		return a[row-1][col-1];
	}
	
	public boolean isFull(int row, int col)  // is site (row, col) full?
	{
		if (row <= 0 || row > N) 
		{
            throw new IllegalArgumentException("index " + row + " is not between 1 and " + N);  
        }
		if (col <= 0 || col > N) 
		{
            throw new IllegalArgumentException("index " + col + " is not between 1 and " + N);  
        }
		
		return uf.connected((row-1)*N+col-1, N*N);
	}
	
	public int numberOfOpenSites()       	 // number of open sites
	{
		return count;
	}
	
	public boolean percolates()              // does the system percolate?
	{
		return uf.connected(N*N, N*N+1);
	}
	
	
	public static void main(String[] args)   // test client (optional)
	{
        int n = StdIn.readInt();
        Percolation pc = new Percolation(n);
        while (!StdIn.isEmpty()) 
        {
            int row = StdIn.readInt();
            int col = StdIn.readInt();
            if (pc.isOpen(row, col)) 
            {	
            	continue;
            }
            pc.open(row, col);
            StdOut.println(row + " " + col);
        }
        StdOut.println(pc.percolates());
	}
}
