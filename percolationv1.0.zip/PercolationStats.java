import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats 
{
	private int T;
	private int N;
	private double[] xt;
	
	public PercolationStats(int n, int trials)    // perform trials independent experiments on an n-by-n grid
	{
		N = n;
		T = trials;
		xt = new double[T];
		for(int t = 1; t <= T; t++)
		{
			Percolation perc = new Percolation(N);
			while(!perc.percolates())
			{
				int row = StdRandom.uniform(1, N+1);
				int col = StdRandom.uniform(1, N+1);
				perc.open(row, col);
			}
			xt[t-1] = (double) perc.numberOfOpenSites() / (N*N);
		}
		
	}
	
	public double mean()                          // sample mean of percolation threshold	
	{
		return StdStats.mean(xt);
	}
	
	public double stddev()                        // sample standard deviation of percolation threshold
	{
		return StdStats.stddev(xt);
	}
	
	public double confidenceLo()                  // low  endpoint of 95% confidence interval
	{
		return mean() - 1.96 * stddev() / Math.sqrt(T);
	}
	
	public double confidenceHi()                  // high endpoint of 95% confidence interval
	{
		return mean() + 1.96 * stddev() / Math.sqrt(T);
	}
	
	public static void main(String[] args)        // test client (described below)
	{
		int n = Integer.parseInt(args[0]);
		int T = Integer.parseInt(args[1]);
		PercolationStats PS = new PercolationStats(n,T);
		StdOut.println("mean                    = " + PS.mean());
		StdOut.println("stddev                  = " + PS.stddev());
		StdOut.println("95% confidence interval = [" + PS.confidenceLo() + ", " + PS.confidenceHi() + "]");
	}
}
