import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private final int t;
    private final double[] xt;
    private final static double CONFIDENCE_95 = 1.96;
    private final double mean;
    private final double stddev;

    public PercolationStats(int n, int trials) // perform trials independent experiments on an n-by-n grid
    {
        if (n <= 0) {
            throw new IllegalArgumentException("index n should be larger than 1.");
        }
        if (trials <= 0) {
            throw new IllegalArgumentException("index trial should be larger than 1.");
        }
        
        t = trials;
        xt = new double[t];
        for (int i = 1; i <= t; i++) {
            Percolation perc = new Percolation(n);
            while (!perc.percolates()) {
                int row = StdRandom.uniform(1, n + 1);
                int col = StdRandom.uniform(1, n + 1);
                perc.open(row, col);
            }
            xt[i - 1] = (double) perc.numberOfOpenSites() / (n * n);
        }
        mean = StdStats.mean(xt);
        stddev = StdStats.stddev(xt);
    }

    public double mean() // sample mean of percolation threshold
    {
        return mean;
    }

    public double stddev() // sample standard deviation of percolation threshold
    {
        return stddev;
    }

    public double confidenceLo() // low endpoint of 95% confidence interval
    {
        return mean() - CONFIDENCE_95 * stddev() / Math.sqrt(t);
    }

    public double confidenceHi() // high endpoint of 95% confidence interval
    {
        return mean() + CONFIDENCE_95 * stddev() / Math.sqrt(t);
    }

    public static void main(String[] args) // test client (described below)
    {
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        PercolationStats PS = new PercolationStats(n, t);
        StdOut.println("mean                    = " + PS.mean());
        StdOut.println("stddev                  = " + PS.stddev());
        StdOut.println("95% confidence interval = [" + PS.confidenceLo() + ", " + PS.confidenceHi() + "]");
    }
}
