
import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int N;
    private int count;
    private boolean[][] a;
    private final WeightedQuickUnionUF uf;
    private final WeightedQuickUnionUF uf2; 

    public Percolation(int n) // create n-by-n grid, with all sites blocked
    {
        if (n <= 0) {
            throw new IllegalArgumentException("index n should be larger than 1.");
        }
        N = n;
        count = 0;
        uf = new WeightedQuickUnionUF(N * N + 2); // The first (N*N) sites are grid sites. (N*N + 1) is the top site and
                                                  // (N*N + 2) is the bottom site
        uf2 = new WeightedQuickUnionUF(N * N + 1);  // just for isFull()
        a = new boolean[N][N];
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < N; ++j) {
                a[i][j] = false;
            }
        }
    }

    public void open(int row, int col) // open site (row, col) if it is not open already
    {
        validate(row);
        validate(col);
        
        row = row - 1;
        col = col - 1;
        if (!a[row][col]) {
            a[row][col] = true;
            count++;
            if (row - 1 >= 0 && a[row - 1][col])
            {
                uf.union(row * N + col, (row - 1) * N + col);
                uf2.union(row * N + col, (row - 1) * N + col);
            }
            if (row + 1 <= N - 1 && a[row + 1][col])
            {
                uf.union(row * N + col, (row + 1) * N + col);
                uf2.union(row * N + col, (row + 1) * N + col);
            }
            if (col + 1 <= N - 1 && a[row][col + 1])
            {
                uf.union(row * N + col, row * N + col + 1);
                uf2.union(row * N + col, row * N + col + 1);
            }
            if (col - 1 >= 0 && a[row][col - 1])
            {
                uf.union(row * N + col, row * N + col - 1);
                uf2.union(row * N + col, row * N + col - 1);
            }
            if (row == 0)
            {
                uf.union(col, N * N);
                uf2.union(col, N * N);
            }
            if (row == N - 1)
                uf.union(N * (N - 1) + col, N * N + 1);
        }
    }

    public boolean isOpen(int row, int col) // is site (row, col) open?
    {
        validate(row);
        validate(col);
        
        return a[row - 1][col - 1];
    }

    public boolean isFull(int row, int col) // is site (row, col) full?
    {
        validate(row);
        validate(col);

        return uf2.connected((row - 1) * N + col - 1, N * N);
    }

    public int numberOfOpenSites() // number of open sites
    {
        return count;
    }

    public boolean percolates() // does the system percolate?
    {
        return uf.connected(N * N, N * N + 1);
    }

    private void validate(int p)
    {
        if (p <= 0 || p > N) {
            throw new IllegalArgumentException("index " + p + " is not between 1 and " + N);
        }
    }
    
    public static void main(String[] args) // test client (optional)
    {
        int n = StdIn.readInt();
        Percolation pc = new Percolation(n);
        while (!StdIn.isEmpty()) {
            int row = StdIn.readInt();
            int col = StdIn.readInt();
            if (pc.isOpen(row, col)) {
                continue;
            }
            pc.open(row, col);
            StdOut.println(row + " " + col);
        }
        StdOut.println(pc.percolates());
    }
}
